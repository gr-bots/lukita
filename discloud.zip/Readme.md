# <p align="center"> Lukita 💙</p> 

### <div align="center"><code> Seu bot multifuncional e simples para o Discord </code></div>
 

-------------------------------------------------------------------------------------------------------------------------------------------

<img src="https://cdn.discordapp.com/attachments/979532798849339464/1004198688790433833/Lukita_bannerzinho_color.png" width="100%">

-------------------------------------------------------------------------------------------------------------------------------------------

 <br>

## 😉 Aprovado nos quesitos : 

   - [X] **Completo em moderação.**
   - [X] **Fácil de usar.**
   - [X] **100% em português.**

 <br>

## 🙋‍♂️ Suporte:

   - Acesse o nosso servidor no Discord clicando [aqui](https://discord.gg/pJyY3zsMmB).

 <br>

## ❗ Regras de Contribuição :

   * **Os pull requests devem conter commits feitos por você.**
   * **Códigos repetidos não serão mesclados.**

 <br>

 ## <p align="center"> 🏆 Desenvolvedor </p> 

<table align="center">
	<tr>
		<td>
            <a href="https://github.com/gr-bots/lukita/graphs/contributors">
              <img src="https://contrib.rocks/image?repo=guidsribeiro/aboutgr" />
            </a>
        </td>
	</tr>
</table>

## <p align="center"> ✨ Contribuidores </p> 

<table align="center">
	<tr>
		<td>
            <a href="https://github.com/onlygr/Lukita/graphs/contributors">
              <img src="https://contrib.rocks/image?repo=onlygr/Lukita" />
            </a>
        </td>
	</tr>
</table>

----------------------------------------------------------

### <p align="center"> Se caso tenha gostado, não deixe de clicar no botão da ⭐ para nos apoiar </p>

----------------------------------------------------------
